Plantilla 1. Diseño y desarrollo de una aplicación web

**Rol:** Actúa como un desarrollador web especializado en HTML, CSS, JavaScript y accesibilidad.

**Objetivo:** Diseñar e implementar una página web para [tipo de proyecto o servicio].

**Contexto del proyecto:**
- Público objetivo: [usuarios a los que va dirigida].
- Contenido principal: [información y funcionalidades que debe incluir].
- Tecnologías: [HTML, CSS, JavaScript u otras].
- Requisitos de diseño: [colores, distribución, estilo y adaptación a móviles].

**Tareas:**
1. Define los requisitos funcionales y visuales.
2. Propón la estructura de la página y sus componentes.
3. Genera el código completo necesario, indicando el nombre de cada archivo.
4. Comprueba la accesibilidad mediante etiquetas semánticas, navegación por teclado y contraste de colores.
5. Explica cómo ejecutar el proyecto y cómo verificar que funciona.

**Criterios de calidad:**
- El diseño debe ser coherente con el público objetivo.
- El código debe ser legible y estar organizado.
- La página debe adaptarse a distintos tamaños de pantalla.
- No afirmes que has probado el código si no has ejecutado las pruebas.

**Formato de respuesta:** Requisitos, estructura de archivos, código, explicación y lista de comprobaciones.

Casos en los que se puede utilizar: 1. Página de reservas y 6. Diseño y mejora de una web.

Plantilla 2. Análisis, corrección y pruebas de código

**Rol:** Actúa como un profesor de programación y desarrollador especializado en [lenguaje o tecnología].

**Objetivo:** Revisar, corregir y comprobar el funcionamiento del siguiente código.

**Contexto:**
- Lenguaje o tecnología: [JavaScript, PHP, SQL, API REST u otro].
- Funcionalidad esperada: [qué debe hacer el programa].
- Entorno de ejecución: [navegador, servidor, base de datos, versión o herramientas].
- Nivel de dificultad: [básico, intermedio o avanzado].

**Código inicial:**
[Pegar aquí el código que se debe revisar].

**Tareas:**
1. Explica brevemente qué hace el código original.
2. Identifica los errores y problemas de legibilidad, funcionamiento, seguridad o gestión de excepciones que sean relevantes.
3. Prioriza los problemas según su gravedad.
4. Muestra el código inicial y el código corregido, explicando los cambios realizados.
5. Diseña pruebas que permitan comprobar el funcionamiento, incluyendo al menos un caso correcto y uno incorrecto.
6. Explica los resultados esperados y cómo reproducir las pruebas.
7. Si el código depende de servicios externos, distingue los errores de respuesta HTTP de los errores de red.

**Criterios de calidad:**
- Mantén la funcionalidad solicitada.
- Evita introducir complejidad innecesaria.
- No inventes resultados de ejecución.
- Si falta información para ejecutar el código, indica qué se necesita.

**Formato de respuesta:** Descripción, problemas detectados, código original, código corregido, pruebas y conclusiones.

Casos en los que se puede utilizar: 2. Revisión de JavaScript, 3. Validación de formularios con PHP, 4. Esquema SQL y normalización, 5. Implementación de una API y 7. Detección y corrección de errores.

Plantilla 3. Documentación y mantenimiento de un proyecto

**Rol:** Actúa como un desarrollador de software responsable de la documentación técnica y el control de versiones.

**Objetivo:** Crear o mejorar la documentación de [nombre y descripción del proyecto].

**Contexto:**
- Tipo de proyecto: [aplicación web, API, base de datos u otro].
- Tecnologías utilizadas: [lenguajes, frameworks, herramientas y versiones].
- Estado actual: [en desarrollo, terminado o en fase de pruebas].
- Público de la documentación: [estudiantes, desarrolladores o usuarios].
- Repositorio Git: [estructura actual o enlace, si está disponible].

**Tareas:**
1. Analiza la estructura del proyecto y la información proporcionada.
2. Elabora un README.md que incluya:
   - Descripción y objetivos.
   - Requisitos previos.
   - Instalación y configuración.
   - Instrucciones de ejecución.
   - Ejemplos de uso.
   - Pruebas y resultados esperados.
   - Limitaciones conocidas.
   - Fuentes y referencias utilizadas.
3. Comprueba que las instrucciones sean coherentes con los archivos y tecnologías reales del proyecto.
4. Identifica la información que falta y evita inventar datos.
5. Propón un historial de cambios mediante Git, con commits pequeños y mensajes descriptivos.
6. Explica cómo verificar la documentación y comprobar que el proyecto se puede ejecutar siguiendo sus instrucciones.

**Criterios de calidad:**
- Utiliza un lenguaje claro y técnico, adecuado al público objetivo.
- Incluye ejemplos reproducibles cuando sea posible.
- Distingue las pruebas realizadas de las que solo se proponen.
- No incluyas contraseñas, claves privadas ni otros datos sensibles.

**Formato de respuesta:** Estructura del README, contenido completo en Markdown, comprobaciones pendientes y propuesta de historial Git.

Caso en el que se puede utilizar: 8. Documentación del banco de prompts y sus ejemplos.


**Url Githb**
https://github.com/aadriiaan/13_2DAW_DAW_1Ev_IA_Bajo_Control